/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ders04Lab;

/**
 *
 * @author anizam
 */
public class Oyuncu {
   int id,TakimId;
   String adi,soyadi;
   

    public Oyuncu(int id, int TakimId, String adi, String soyadi) {
        this.id = id;
        this.TakimId = TakimId;
        this.adi = adi;
        this.soyadi = soyadi;
        
    }

   
   
}
