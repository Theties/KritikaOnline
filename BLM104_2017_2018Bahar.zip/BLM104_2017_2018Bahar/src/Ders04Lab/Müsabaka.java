/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ders04Lab;

/**
 *
 * @author Theties
 */
public class M�sabaka  {
int M�sabakaID;

    public void setM�sabakaID(int M�sabakaID) {
        this.M�sabakaID = M�sabakaID;
    }
Takim KazananTakim;
Takim ilkTakim;
    Takim ikinciTakim;

    public M�sabaka() {
    }

    public M�sabaka(Takim ilkTakim, Takim ikinciTakim) {
        this.ilkTakim = ilkTakim;
        this.ikinciTakim = ikinciTakim;
    }

    public void setKazananTakim(Takim KazananTakim) {
        this.KazananTakim = KazananTakim;
    }

   
    
}
